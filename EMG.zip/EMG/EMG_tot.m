clc
clear
close all
%% Entering raw data
[file path]=uigetfile('*.xlsx');
EMG=importdata([path file]);
% t=EMG.data(:,1);
% t1=t(1,1)*0.01;
% tfn=length(t);
% tf=(t(tfn,1)*0.01)+0.009;
% t=t1:0.001:tf;
% tf2=length(t);
% t=0:0.001:((tf2*0.001)-0.001);
% t=t';
%
t=0:0.001:2.159;
%t=t+1.33;
t=t';
raw_RRF=EMG.data(:,3);raw_RRF=raw_RRF(~isnan(raw_RRF));
raw_RVL=EMG.data(:,4);raw_RVL=raw_RVL(~isnan(raw_RVL));
raw_RBF=EMG.data(:,5);raw_RBF=raw_RBF(~isnan(raw_RBF));
raw_RGAST=EMG.data(:,6);raw_RGAST=raw_RGAST(~isnan(raw_RGAST));
raw_LRF=EMG.data(:,7);raw_LRF=raw_LRF(~isnan(raw_LRF));
raw_LVL=EMG.data(:,8);raw_LVL=raw_LVL(~isnan(raw_LVL));
raw_LBF=EMG.data(:,9);raw_LBF=raw_LBF(~isnan(raw_LBF));
raw_LGAST=EMG.data(:,10);raw_LGAST=raw_LGAST(~isnan(raw_LGAST));
raw_LMF=EMG.data(:,11);raw_LMF=raw_LMF(~isnan(raw_LMF));
raw_LGLUT=EMG.data(:,12);raw_LGLUT=raw_LGLUT(~isnan(raw_LGLUT));
 figure(1)
%  subplot(2,5,1)
 plot(t,raw_RRF),title('Raw RRF EMG data')
%  subplot(2,5,2)
%  plot(t,raw_RVL),title('Raw RVL EMG data')
%  subplot(2,5,3)
%  plot(t,raw_RBF),title('Raw RBF EMG data')
%  subplot(2,5,4)
%  plot(t,raw_RGAST),title('Raw RGAST-M EMG data')
%  subplot(2,5,5)
%  plot(t,raw_LRF),title('Raw LRF EMG data')
%  subplot(2,5,6)
%  plot(t,raw_LVL),title('Raw LVL EMG data')
%  subplot(2,5,7)
%  plot(t,raw_LBF),title('Raw LBF EMG data')
%  subplot(2,5,8)
%  plot(t,raw_LGAST),title('Raw LGAST-M EMG data')
%  subplot(2,5,9)
%  plot(t,raw_LMF),title('Raw LMF EMG data')
%  subplot(2,5,10)
%  plot(t,raw_LGLUT),title('Raw LGLUT-M EMG data')

%% Removing DC bias
RRF=detrend(raw_RRF);
RVL=detrend(raw_RVL);
RBF=detrend(raw_RBF);
RGAST=detrend(raw_RGAST);
LRF=detrend(raw_LRF);
LVL=detrend(raw_LVL);
LBF=detrend(raw_LBF);
LGAST=detrend(raw_LGAST);
LMF=detrend(raw_LMF);
LGLUT=detrend(raw_LGLUT);

%% Frequency analysis
%RRF
Fs=1000;                    % Sampling frequency 
L=length(RRF);             % Length of signal 
NFFT=2^nextpow2(L);         % Next power of 2 from length of y 
freq=Fs/2*linspace(0,1,NFFT/2+1); 
dataFFT=fft(RRF,NFFT)/L; 
dataPowerSpectral = dataFFT.*conj(dataFFT)/NFFT; 
dataFFT=2*abs(dataFFT(1:NFFT/2+1)); 
dataPowerSpectral = dataPowerSpectral(1:NFFT/2+1);  
%RVL
Fs=1000;                    % Sampling frequency 
L1=length(RVL);             % Length of signal 
NFFT1=2^nextpow2(L1);         % Next power of 2 from length of y 
freq1=Fs/2*linspace(0,1,NFFT1/2+1); 
dataFFT1=fft(RVL,NFFT1)/L1; 
dataPowerSpectral1 = dataFFT1.*conj(dataFFT1)/NFFT1; 
dataFFT1=2*abs(dataFFT1(1:NFFT1/2+1)); 
dataPowerSpectral1 = dataPowerSpectral1(1:NFFT1/2+1); 
%RBF
Fs=1000;                    % Sampling frequency 
L2=length(RBF);             % Length of signal 
NFFT2=2^nextpow2(L2);         % Next power of 2 from length of y 
freq2=Fs/2*linspace(0,1,NFFT2/2+1); 
dataFFT2=fft(RBF,NFFT2)/L2; 
dataPowerSpectral2 = dataFFT2.*conj(dataFFT2)/NFFT2; 
dataFFT2=2*abs(dataFFT2(1:NFFT2/2+1)); 
dataPowerSpectral2 = dataPowerSpectral2(1:NFFT2/2+1); 
%GAST
Fs=1000;                    % Sampling frequency 
L3=length(RGAST);             % Length of signal 
NFFT3=2^nextpow2(L3);         % Next power of 2 from length of y 
freq3=Fs/2*linspace(0,1,NFFT3/2+1); 
dataFFT3=fft(RGAST,NFFT3)/L3; 
dataPowerSpectral3 = dataFFT3.*conj(dataFFT3)/NFFT3; 
dataFFT3=2*abs(dataFFT3(1:NFFT3/2+1)); 
dataPowerSpectral3 = dataPowerSpectral3(1:NFFT3/2+1); 
%LRF
Fs=1000;                    % Sampling frequency 
L4=length(LRF);             % Length of signal 
NFFT4=2^nextpow2(L4);         % Next power of 2 from length of y 
freq4=Fs/2*linspace(0,1,NFFT4/2+1); 
dataFFT4=fft(LRF,NFFT4)/L4; 
dataPowerSpectral4 = dataFFT4.*conj(dataFFT4)/NFFT4; 
dataFFT4=2*abs(dataFFT4(1:NFFT4/2+1)); 
dataPowerSpectral4 = dataPowerSpectral4(1:NFFT4/2+1);  
%LVL
Fs=1000;                    % Sampling frequency 
L5=length(LVL);             % Length of signal 
NFFT5=2^nextpow2(L5);         % Next power of 2 from length of y 
freq5=Fs/2*linspace(0,1,NFFT5/2+1); 
dataFFT5=fft(LVL,NFFT5)/L5; 
dataPowerSpectral5 = dataFFT5.*conj(dataFFT5)/NFFT5; 
dataFFT5=2*abs(dataFFT5(1:NFFT5/2+1)); 
dataPowerSpectral5 = dataPowerSpectral5(1:NFFT5/2+1); 
%LBF
Fs=1000;                    % Sampling frequency 
L6=length(LBF);             % Length of signal 
NFFT6=2^nextpow2(L6);         % Next power of 2 from length of y 
freq6=Fs/2*linspace(0,1,NFFT6/2+1); 
dataFFT6=fft(LBF,NFFT6)/L6; 
dataPowerSpectral6 = dataFFT6.*conj(dataFFT6)/NFFT6; 
dataFFT6=2*abs(dataFFT6(1:NFFT6/2+1)); 
dataPowerSpectral6 = dataPowerSpectral6(1:NFFT6/2+1);  
%LGAST
Fs=1000;                    % Sampling frequency 
L7=length(LGAST);             % Length of signal 
NFFT7=2^nextpow2(L7);         % Next power of 2 from length of y 
freq7=Fs/2*linspace(0,1,NFFT7/2+1); 
dataFFT7=fft(LGAST,NFFT7)/L7; 
dataPowerSpectral7 = dataFFT7.*conj(dataFFT7)/NFFT7; 
dataFFT7=2*abs(dataFFT7(1:NFFT7/2+1)); 
dataPowerSpectral7 = dataPowerSpectral7(1:NFFT7/2+1);

%LMF
Fs=1000;                    % Sampling frequency 
L8=length(LMF);             % Length of signal 
NFFT8=2^nextpow2(L8);         % Next power of 2 from length of y 
freq8=Fs/2*linspace(0,1,NFFT8/2+1); 
dataFFT8=fft(LMF,NFFT8)/L8; 
dataPowerSpectral8 = dataFFT8.*conj(dataFFT8)/NFFT8; 
dataFFT8=2*abs(dataFFT8(1:NFFT8/2+1)); 
dataPowerSpectral8 = dataPowerSpectral8(1:NFFT8/2+1);

%LGLUT
Fs=1000;                    % Sampling frequency 
L9=length(LGLUT);             % Length of signal 
NFFT9=2^nextpow2(L9);         % Next power of 2 from length of y 
freq9=Fs/2*linspace(0,1,NFFT9/2+1); 
dataFFT9=fft(LGLUT,NFFT9)/L9; 
dataPowerSpectral9 = dataFFT9.*conj(dataFFT9)/NFFT9; 
dataFFT9=2*abs(dataFFT9(1:NFFT9/2+1)); 
dataPowerSpectral9 = dataPowerSpectral9(1:NFFT9/2+1);

%% Removing median frequency
%RRF
f=find(dataPowerSpectral==max(dataPowerSpectral));
freqToRemove = 50; % The power line frequency 
wo=freqToRemove/(Fs/2); 
bw=wo/50; 
[numIirnotch,denIirnotch]=iirnotch(wo,bw);  
RRF=filtfilt(numIirnotch,denIirnotch,RRF);
%RVL
f1=find(dataPowerSpectral1==max(dataPowerSpectral1));
freqToRemove1 = 50; % The power line frequency 
wo1=freqToRemove1/(Fs/2); 
bw1=wo1/50; 
[numIirnotch1,denIirnotch1]=iirnotch(wo1,bw1);  
RVL=filtfilt(numIirnotch1,denIirnotch1,RVL);
%RBF
f2=find(dataPowerSpectral2==max(dataPowerSpectral2));
freqToRemove2 = 50; % The power line frequency 
wo2=freqToRemove2/(Fs/2); 
bw2=wo2/50; 
[numIirnotch2,denIirnotch2]=iirnotch(wo2,bw2);  
RBF=filtfilt(numIirnotch2,denIirnotch2,RBF);
%RGAST
f3=find(dataPowerSpectral3==max(dataPowerSpectral3));
freqToRemove3 = 50; % The power line frequency 
wo3=freqToRemove3/(Fs/2); 
bw3=wo3/50; 
[numIirnotch3,denIirnotch3]=iirnotch(wo3,bw3);  
RGAST=filtfilt(numIirnotch3,denIirnotch3,RGAST);
%LRF
f4=find(dataPowerSpectral4==max(dataPowerSpectral4));
freqToRemove4 = 50; % The power line frequency 
wo4=freqToRemove4/(Fs/2); 
bw4=wo4/50; 
[numIirnotch4,denIirnotch4]=iirnotch(wo4,bw4);  
LRF=filtfilt(numIirnotch4,denIirnotch4,LRF);
%LVL
f5=find(dataPowerSpectral5==max(dataPowerSpectral5));
freqToRemove5 = 50; % The power line frequency 
wo5=freqToRemove5/(Fs/2); 
bw5=wo5/50; 
[numIirnotch5,denIirnotch5]=iirnotch(wo5,bw5);  
LVL=filtfilt(numIirnotch5,denIirnotch5,LVL);
%LBF
f6=find(dataPowerSpectral6==max(dataPowerSpectral6));
freqToRemove6 = 50; % The power line frequency 
wo6=freqToRemove6/(Fs/2); 
bw6=wo6/50; 
[numIirnotch6,denIirnotch6]=iirnotch(wo6,bw6);  
LBF=filtfilt(numIirnotch6,denIirnotch6,LBF);
%LGAST
f7=find(dataPowerSpectral7==max(dataPowerSpectral7));
freqToRemove7 = 50; % The power line frequency 
wo7=freqToRemove7/(Fs/2); 
bw7=wo7/50; 
[numIirnotch7,denIirnotch7]=iirnotch(wo7,bw7);  
LGAST=filtfilt(numIirnotch7,denIirnotch7,LGAST);

%LMF
f8=find(dataPowerSpectral8==max(dataPowerSpectral8));
freqToRemove8 = 50; % The power line frequency 
wo8=freqToRemove8/(Fs/2); 
bw8=wo8/50; 
[numIirnotch8,denIirnotch8]=iirnotch(wo8,bw8);  
LMF=filtfilt(numIirnotch8,denIirnotch8,LMF);

%LGLUT
f9=find(dataPowerSpectral9==max(dataPowerSpectral9));
freqToRemove9 = 50; % The power line frequency 
wo9=freqToRemove9/(Fs/2); 
bw9=wo9/50; 
[numIirnotch9,denIirnotch9]=iirnotch(wo9,bw9);  
LGLUT=filtfilt(numIirnotch9,denIirnotch9,LGLUT);

%% Calculation of median frequency

%RRF
normCumsumPsd=cumsum(dataPowerSpectral)./sum(dataPowerSpectral); 
Ind=find(normCumsumPsd <=0.5,1,'last'); 
fprintf('Median RRF frequency is %2.3f Hz\n',freq(Ind)); 

%RVL
normCumsumPsd1=cumsum(dataPowerSpectral1)./sum(dataPowerSpectral1); 
Ind1=find(normCumsumPsd1 <=0.5,1,'last'); 
fprintf('Median RVL frequency is %2.3f Hz\n',freq1(Ind1)); 

%RBF
normCumsumPsd2=cumsum(dataPowerSpectral2)./sum(dataPowerSpectral2); 
Ind2=find(normCumsumPsd2 <=0.5,1,'last'); 
fprintf('Median RBF frequency is %2.3f Hz\n',freq2(Ind2));

%RGAST
normCumsumPsd3=cumsum(dataPowerSpectral3)./sum(dataPowerSpectral3); 
Ind3=find(normCumsumPsd3 <=0.5,1,'last'); 
fprintf('Median RGAST frequency is %2.3f Hz\n',freq3(Ind3)); 

%LRF
normCumsumPsd4=cumsum(dataPowerSpectral4)./sum(dataPowerSpectral4); 
Ind4=find(normCumsumPsd4 <=0.5,1,'last'); 
fprintf('Median LRF frequency is %2.3f Hz\n',freq4(Ind4)); 

%LVL
normCumsumPsd5=cumsum(dataPowerSpectral5)./sum(dataPowerSpectral5); 
Ind5=find(normCumsumPsd5 <=0.5,1,'last'); 
fprintf('Median LVL frequency is %2.3f Hz\n',freq5(Ind5)); 

%LBF
normCumsumPsd6=cumsum(dataPowerSpectral6)./sum(dataPowerSpectral6); 
Ind6=find(normCumsumPsd6 <=0.5,1,'last'); 
fprintf('Median LBF frequency is %2.3f Hz\n',freq6(Ind6));

%LGAST
normCumsumPsd7=cumsum(dataPowerSpectral7)./sum(dataPowerSpectral7); 
Ind7=find(normCumsumPsd7 <=0.5,1,'last'); 
fprintf('Median LGAST frequency is %2.3f Hz\n',freq7(Ind7)); 

%LMF
normCumsumPsd8=cumsum(dataPowerSpectral8)./sum(dataPowerSpectral8); 
Ind8=find(normCumsumPsd8 <=0.5,1,'last'); 
fprintf('Median LMF frequency is %2.3f Hz\n',freq8(Ind8)); 

%LGLUT
normCumsumPsd9=cumsum(dataPowerSpectral9)./sum(dataPowerSpectral9); 
Ind9=find(normCumsumPsd9 <=0.5,1,'last'); 
fprintf('Median LGLUT frequency is %2.3f Hz\n',freq9(Ind9));

%% Full rectify
RRF=abs(RRF);
RVL=abs(RVL);
RBF=abs(RBF);
RGAST=abs(RGAST);
LRF=abs(LRF);
LVL=abs(LVL);
LBF=abs(LBF);
LGAST=abs(LGAST);
LMF=abs(LMF);
LGLUT=abs(LGLUT);

%% Low pass filter

%RRF
freqCutOff=5; 
Wn=freqCutOff/(Fs/2); 
order=4;
[numButter,denButter]=butter(order,Wn,'low'); 
RRF=filtfilt(numButter,denButter,RRF);  

%RVL
freqCutOff1=2; 
Wn1=freqCutOff1/(Fs/2); 
order1=4;
[numButter1,denButter1]=butter(order1,Wn1,'low'); 
RVL=filtfilt(numButter1,denButter1,RVL); 

%RBF
freqCutOff2=2; 
Wn2=freqCutOff2/(Fs/2); 
order2=4;
[numButter2,denButter2]=butter(order2,Wn2,'low'); 
RBF=filtfilt(numButter2,denButter2,RBF);

%GAST
freqCutOff3=2; 
Wn3=freqCutOff3/(Fs/2); 
order3=4;
[numButter3,denButter3]=butter(order3,Wn3,'low'); 
RGAST=filtfilt(numButter3,denButter3,RGAST); 

%LRF
freqCutOff4=2; 
Wn4=freqCutOff4/(Fs/2); 
order4=5;
[numButter4,denButter4]=butter(order4,Wn4,'low'); 
LRF=filtfilt(numButter4,denButter4,LRF); 

%LVL
freqCutOff5=2; 
Wn5=freqCutOff5/(Fs/2); 
order5=4;
[numButter5,denButter5]=butter(order5,Wn5,'low'); 
LVL=filtfilt(numButter5,denButter5,LVL);  

%LBF
freqCutOff6=2; 
Wn6=freqCutOff6/(Fs/2); 
order6=4;
[numButter6,denButter6]=butter(order6,Wn6,'low'); 
LBF=filtfilt(numButter6,denButter6,LBF);  

%LGAST
freqCutOff7=2; 
Wn7=freqCutOff7/(Fs/2); 
order7=4;
[numButter7,denButter7]=butter(order7,Wn7,'low'); 
LGAST=filtfilt(numButter7,denButter7,LGAST);  

%LMF
freqCutOff8=2; 
Wn8=freqCutOff8/(Fs/2); 
order8=4;
[numButter8,denButter8]=butter(order8,Wn8,'low'); 
LMF=filtfilt(numButter8,denButter8,LMF);  

%LGLUT
freqCutOff9=2; 
Wn9=freqCutOff9/(Fs/2); 
order9=4;
[numButter9,denButter9]=butter(order9,Wn9,'low'); 
LGLUT=filtfilt(numButter9,denButter9,LGLUT);  

%% RMS signal smoothing

%RRF
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS(i)=rms(RRF(i:i+windowLength));
end 
data_RMS=data_RMS./max(data_RMS);
figure(2)
% subplot(1,3,1)
plot(t(1:L - windowLength),data_RMS),title('normalized RMS RRF EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%RVL
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS1=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS1(i)=rms(RVL(i:i+windowLength));
end 
data_RMS1=data_RMS1./max(data_RMS1);
figure(3)
% subplot(1,3,2)
plot(t(1:L - windowLength),data_RMS1),title('normalized RMS RVL EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%RBF
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS2=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS2(i)=rms(RBF(i:i+windowLength));
end 
data_RMS2=data_RMS2./max(data_RMS2);
figure(4)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS2),title('normalized RMS RBF EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%RGAST-M
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS3=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS3(i)=rms(RGAST(i:i+windowLength));
end 
data_RMS3=data_RMS3./max(data_RMS3);
figure(5)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS3),title('normalized RMS RGAST-M EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%LRF
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS4=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS4(i)=rms(LRF(i:i+windowLength));
end 
data_RMS4=data_RMS4./max(data_RMS4);
figure(6)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS4),title('normalized RMS LRF EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%LVL
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS5=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS5(i)=rms(LVL(i:i+windowLength));
end 
data_RMS5=data_RMS5./max(data_RMS5);
figure(7)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS5),title('normalized RMS LVL EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%LBF
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS6=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS6(i)=rms(LBF(i:i+windowLength));
end 
data_RMS6=data_RMS6./max(data_RMS6);
figure(8)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS6),title('normalized RMS LBF EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%LGAST-M
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS7=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS7(i)=rms(LGAST(i:i+windowLength));
end 
data_RMS7=data_RMS7./max(data_RMS7);
figure(9)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS7),title('normalized RMS LGAST-M EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%LMF
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS8=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS8(i)=rms(LMF(i:i+windowLength));
end 
data_RMS8=data_RMS8./max(data_RMS8);
figure(10)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS8),title('normalized LMF RBF EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%LGLUT-M
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS9=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS9(i)=rms(LGLUT(i:i+windowLength));
end 
data_RMS9=data_RMS9./max(data_RMS9);
figure(11)
% subplot(1,3,3)
plot(t(1:L - windowLength),data_RMS9),title('normalized RMS LGLUT-M EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))

%% Rewrite EMG file

finall(:,1)= t(1:L - windowLength);
finall(:,2)= data_RMS;
finall(:,3)= data_RMS1;
finall(:,4)= data_RMS2;
finall(:,5)= data_RMS3;
finall(:,6)= data_RMS4;
finall(:,7)= data_RMS5;
finall(:,8)= data_RMS6;
finall(:,9)= data_RMS7;
finall(:,10)= data_RMS8;
finall(:,11)= data_RMS9;
% 
% filename = 'C:\Users\ASUS\Desktop\EMG analysis\Sabetimani\EMG-RRF1-1.xlsx';
% xlswrite(filename,finall);
