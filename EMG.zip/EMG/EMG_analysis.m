clc
clear
close all

%% loading EMG data
[file,path]=uigetfile('*.txt');
data_txt=importdata([path,file]);
t=data_txt.data(:,1); %time
raw_data=data_txt.data(:,2); %raw EMG signal
raw_data=raw_data(~isnan(raw_data));
t=t(1:length(raw_data)); N=length(t);
figure; plot(t,raw_data); title('raw EMG signal')

%% removing zero drift of EMG signal
data=detrend(raw_data);
figure; plot(t,data); title('EMG signal')

%% rectifing EMG signal
data_abs=abs(data);
figure; plot(t,data_abs); title('rectified EMG signal')

%% butter worth filter of EMG signal
order=5;
fc=50; %cutt-off frequency, Hz
fs=1000; %sampling frequency, Hz
wn=fc/(fs/2); %normalized cut-off frequency
[b,a]=butter(order,wn,'low'); 
data_butter=filtfilt(b,a,data_abs); %low-pass butter worth filter
figure; plot(t,data_butter); title('low pass filter of EMG signal')

%% root mean square of EMG signal
w=round((50/1000)*fs); %window length
for i=1:N-w
    data_rms(i)=rms(data_butter(i:i+w));
%     data_rms(i)=data_rms(i)./max(data_rms);
end
figure; plot(t(1:N-w),data_rms); title('root mean square of EMG signal')
