clc
clear
close all
%% Entering raw data
[file path]=uigetfile('*.xlsx');
EMG=importdata([path file]);
t=EMG(4:end,1);
raw_RRF=EMG(:,2);
raw_RVL=EMG(:,3);
raw_RBF=EMG(:,4);
raw_RRF=EMG(:,5);
raw_RRF=EMG(:,2);
raw_RRF=EMG(:,2);
raw_RRF=EMG(:,2);
raw_RRF=EMG(:,2);
raw_RRF=EMG(:,2);
%raw_data=raw_data(~isnan(raw_data));
t=t(1:length(raw_RRF));
%figure(1),plot(t,raw_data),title('Raw EMG data');
%% Removing DC bias
data=detrend(raw_data);
figure(2),plot(t,data),title('Removed DC offset EMG data');
%% Frequency analysis
Fs=1000;                    % Sampling frequency 
L=length(data);             % Length of signal 
NFFT=2^nextpow2(L);         % Next power of 2 from length of y 
freq=Fs/2*linspace(0,1,NFFT/2+1); 
dataFFT=fft(data,NFFT)/L; 
dataPowerSpectral = dataFFT.*conj(dataFFT)/NFFT; 
dataFFT=2*abs(dataFFT(1:NFFT/2+1)); 
dataPowerSpectral = dataPowerSpectral(1:NFFT/2+1);  

figure(3),plot(freq,dataFFT),title('Single-Sided Amplitude Spectrum of y(t)'),xlabel('Frequeny (Hz)');
figure(4),plot(freq,dataPowerSpectral),title('Power spectral density'),xlabel('Frequeny (Hz)');

%% Removing median frequency
f=find(dataPowerSpectral==max(dataPowerSpectral));
freqToRemove = 50; % The power line frequency 
wo=freqToRemove/(Fs/2); 
bw=wo/35; 
[numIirnotch,denIirnotch]=iirnotch(wo,bw);  
data=filtfilt(numIirnotch,denIirnotch,data);

%% Calculation of median frequency
normCumsumPsd=cumsum(dataPowerSpectral)./sum(dataPowerSpectral); 
Ind=find(normCumsumPsd <=0.5,1,'last'); 
fprintf('Median frequency is %2.3f Hz\n',freq(Ind)); 
figure(5),plot(freq,normCumsumPsd),grid on,title(['Median frequency is ' num2str(freq(Ind)) ' Hz']);
%% Full rectify
data=abs(data);
figure(6),plot(t,data),title('Full rectify EMG signal');

%% Low pass filter
freqCutOff=50; 
Wn=freqCutOff/(Fs/2); 
order=5;
[numButter,denButter]=butter(order,Wn,'low'); 
data=filtfilt(numButter,denButter,data);  
figure(7),plot(t,data),title('Lowpass Filtered EMG Signal');
%% RMS signal smoothing
windowLength=round((50/1000) * Fs); % 0.050(sec) * (Hz) 
data_RMS=zeros(L-windowLength,1); 
for i=1:L-windowLength 
%     data_RMS(i)=sqrt(sum(data(i:i+windowLength).^2,1)/windowLength); 
    data_RMS(i)=rms(data(i:i+windowLength));
end 
% data_RMS=data_RMS./max(data_RMS);
figure(8),plot(t(1:L - windowLength),data_RMS),title('normalized RMS EMG Signal');
Muscle_power=max(cumsum(dataPowerSpectral))
